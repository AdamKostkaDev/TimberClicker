<template>
    <div class="container">
      <img class="tree" src="../assets/tree.png" alt="" @mousedown="startTimer" @mouseup="endTimer">
      <div class="stats">
        <div class="stat"><h3> CPS</h3>  <p>{{ cps }}</p></div>
        <div class="stat">  <h3>Times Clicked </h3><p>{{ timesClicked }}</p></div>
      
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        startTime: null,
        endTime: null,
        clicks: 0,
        cps: 0,
        idleTimer: null,
      };
    },
    computed: {
      timesClicked() {
        return this.clicks;
      }
    },
    methods: {
      startTimer() {
        if (!this.startTime) {
          this.startTime = new Date().getTime();
        }
  
        this.clicks++;
  
        clearInterval(this.idleTimer);
        this.idleTimer = setInterval(() => {
          this.resetCPS();
        }, 10000);
      },
      endTimer() {
        clearInterval(this.idleTimer);
        if (this.startTime) {
          this.endTime = new Date().getTime();
          const timeElapsed = (this.endTime - this.startTime) / 1000;
          this.cps = (this.clicks / timeElapsed).toFixed(2);
        }
      },
      resetCPS() {
        this.startTime = null;
        this.endTime = null;

        this.cps = 0;
      },
    },
  };
  </script>
  
  <style>

  .container{
    display: flex;
    flex-direction: column;
 align-items: center;
  }
  .tree {
    height: 50vh;
  }

  .stats{
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 10vh;

  }
  .stat{

    padding: 17px;
    text-transform: uppercase;
    text-align: center;
    width: 200px;
    background-image: url(../assets/shopitem.png);
    background-position: center;
    background-repeat: no-repeat;
    background-size: contain;
    display: flex;
    flex-direction: column;
    
  }
  @media screen and (max-width: 1250px) {
 .stat{
    font-size: 10px
 }
}
@media screen and (max-width: 800px) {
 .stats{
    flex-direction: column;
 }
 .tree{
    height: 40vh;
    padding-bottom: 5vh
 }
}
  </style>
  
  
  <!-- https://codepen.io/FelixLuciano/pen/MWavXmy 

CPS jsem si pomohl zde

-->