<script setup>
</script>

<template>
  <main>
    <img src="../assets/cloud.png" alt="" class="cloud1 cloud-default">
    <img src="../assets/cloud.png" alt="" class="cloud2 cloud-default">
    <img src="../assets/cloud.png" alt="" class="cloud3 cloud-default">
<img class="heading" src="../assets/menu2.png" alt="">
        <RouterLink to="/game"><img class="play" src="../assets/play2.png" alt=""></RouterLink>
  </main>

</template>

<style>
body{
  height: 100vh;
  width: 100vw;
  padding: 0;
  margin: 0;
  overflow: hidden;
  
}
main{
  position: relative;
  padding: 0;
  margin: 0;
  height: 100vh;
  width: 100vw;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  background-color: rgb(190, 190, 190);
  gap: 40vh;
  background-image: url(../assets/mountain.png);
  background-repeat: no-repeat;
  background-position-x: center;
  background-position-y: 200%;

  overflow-x: hidden;
}
.heading{
  height: 35vh;
  filter: brightness(1.2);
}
a{
  text-decoration: none;
  color: black;
}
.play{
  height: 10vh;
  transition: 0.5s;

}
.play:hover{
  scale: 1.2;
}
@keyframes slidein1 {
0% {left: 70vw;}
50% {left: 150vw;}
100% {left: -50vw}
}
@keyframes slidein2 {
0% {  left: 10vw;}
50% {left: -150vw;}
100% {left: 150vw}
}
@keyframes slidein3 {
0% {  left: 30vw;}
50% {left: 110vw;}
100% {left: -50vw}
} 
.cloud-default{
  position: absolute;
  height: 15vh;
  animation-fill-mode: forwards;
  animation-iteration-count: infinite;
  animation-direction: alternate;  
}
.cloud1{
  left: 70vw;
  top: 10vh;
  animation: slidein1 100s;

}
.cloud2{
left: 10vw;
  height: 18vh;
  top: 18vh;

  animation: slidein2 100s;
}
.cloud3{
  left: 30vw;
  height: 9vh;
  top: 4vh;

  animation: slidein3 100s;
}
@media screen and (max-width: 700px) {
.heading{
  height: 20vh;
}
.play{
  height: 5vh;
}
}

</style>