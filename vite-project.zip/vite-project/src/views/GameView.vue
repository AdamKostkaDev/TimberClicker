<script>
import TreeOne from "../components/TreeOne.vue";
export default {
  components: {
    TreeOne,
  },
  data() {
    return {
      money: 0,
      clickValue: 1,
      betterCursorMultiply: 0.1,
      betterCursorPrice: 10,
      helpingHandPrice: 10,
      menuActive: false
    };
  },
  methods: {
    mainClicked() {
      this.money += this.clickValue
    },
    betterCursor() {
      if (this.money>=this.betterCursorPrice) {
        this.clickValue = this.clickValue + this.betterCursorMultiply
        this.money = this.money - this.betterCursorPrice
        this.betterCursorPrice = Math.floor(this.betterCursorPrice + (3 * this.betterCursorPrice))
      }
    },
    helpingHand() {
      if (this.money>=this.helpingHandPrice) {
        this.money = this.money - this.helpingHandPrice
        setInterval(() => {
        this.money += 0.1
       }, 1000) 
      }

    },
    sawmill() {


    },
    weatherMan() {


    },
    newTree() {

    },
    toggleMenu() {
      this.menuActive = !this.menuActive;
    },
  },
};
</script>

<template>
  <div class="gameContainer">
    <div class="money">{{ Math.floor(money) }}€</div>
    <div class="menu-toggle" @click="toggleMenu">SHOP</div>
  <content>
      <TreeOne @click="mainClicked" />
  </content>
  <div class="shop">
  <div class="shopitem" @click="betterCursor">
    <h2>Better Axe</h2>
    <h3>{{ betterCursorPrice }}€</h3>
    <p>Click gives you more wood</p>
  </div>
  <div class="shopitem" @click="helpingHand">
    <h2>Helping Hand</h2>
    <h3>{{ helpingHandPrice }}€</h3>
    <p>Gives you passive income</p>
    </div>
  <div class="shopitem" @click="sawmill">
    <h2>Sawmill</h2>
    <h3>{{ sawmillPrice }}€</h3>
    <p>Makes every upgrade 50%</p>
  </div>
  <div class="shopitem" @click="weatherMan">
    <h2>Weather man</h2>
    <h3>{{ weatherManPrice }}€</h3>
    <p>Weather does not affect income</p>
  </div>
  <div class="shopitem" @click="newTree">
    <h2>New Tree</h2>
    <h3>{{ newTreePrice }}€</h3>
    <p>Restart with a 1.1 multiplier</p>
  </div>
</div>

  </div>
</template>

<style>
p,h1,h2,h3{
  margin: 0;
  padding: 0;
}
body {
  margin: 0;
  display: flex;
  height: 100vh;
  width: 100vw;
  background-color: rgb(190, 190, 190);
  background-image: url(../assets/forestbg.png);
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
}

content{
  width: 100vw;
  height: 80vh;
  display: flex;
  justify-content: center;
  align-items: center;

}
.shop{
  display: flex;
  height: 20vh;
  width: 100vw;
  align-items:center;

} 
.shop>.shopitem{
  height: 18vh;
  width: 20vw;
  
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  background-image: url(../assets/shopitem.png);
  background-size:contain;
  background-repeat: no-repeat;
  background-position: center;
  padding: 30px;
}
.money {
  position: absolute;
  top: 5vh;
  right: 5vh;
  background-color: rgb(223, 222, 222);
  padding: 10px;
  border-radius: 5px;
  font-size: 30px;
  font-weight: 700;
  
}

@media screen and (max-width: 1350px) {
 .shopitem{
    font-size: 13px
 }
}
@media screen and (max-width: 1050px) {
 .shopitem{
    font-size: 10px
 }
}
@media screen and (max-width: 970px) {
.gameContainer{
  display: flex;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
  justify-content: center;
} 
.shop{
  flex-direction: column;
  order: 0;
  height: 100vh;
  width: 20vw;
}
content{
  order: 2;
  align-items: center;
  height: 100vh;
  width: 70vw;
}

}
@media screen and (max-width: 650px) {
.shop{
  align-items: baseline;
}
}

.menu-toggle {
  display: none;
  position: absolute;
  top: 5vh;
  left: 5vh;
  background-color: rgb(223, 222, 222);
  padding: 10px;
  border-radius: 5px;
  font-size: 30px;
  font-weight: 700;
  
}

@media (max-width: 650px) {
  .shop {
    display: none;
  }
  .menu-toggle {
  display: flex;
}

}
</style>
