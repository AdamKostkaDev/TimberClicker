<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>


  <RouterView />
</template>

<style>
@import url('https://fonts.googleapis.com/css2?family=Sedgwick+Ave+Display&display=swap');
body{
  font-family: 'Sedgwick Ave Display', cursive;
  overflow: hidden;
}

</style>
